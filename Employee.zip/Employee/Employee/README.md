For this project I was revising Create, Read, Update, and Delete (CRUD) operations. 
CRUD operations are essential computer based Information Systems because the define 
the behaviour in which an application will capture and manage data for users and system owners. 
Here, I've implemented CRUD operations without the use of services, such an API or database.

(1) Defined the structure the data I'll be working with. This could be an array of objects, where each object represents a record in the data set.
(2) Created functions to perform CRUD operations on the data.
(3) Built a user interface (UI) to interact with the CRUD functions.
(4) Implemented event handlers or listeners to capture user input from the UI elements and call the appropriate CRUD functions accordingly. (This did not for this project).
(5) Updated the UI to reflect changes. 

Shortcomings:
On this project project I failed to implement event handling for user input validation and data duplication.  