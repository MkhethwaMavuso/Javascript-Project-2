var selectedRow = null;
function onFormSubmit(e){
    event.preventDefault();
    var formData = readFormData();
    if(selectedRow === null){
        insertNewRecord(formData);
    }else{
        updateRecord(formData)
    }
    resetForm();
    }
// Read operation using this function
function readFormData(){
    var formData = {};
    formData["fullName"] = document.getElementById("fullName").value;
    formData["empCode"] = document.getElementById("empCode").value;
    formData["salary"] = document.getElementById("salary").value;
    formData["city"] = document.getElementById("city").value;
    return formData;
}
// Form validation function 
/*
function validateForm() {
    var fullName = document.getElementById("fullName").value;
    var empCode = document.getElementById("empCode").value;
    var salary = document.getElementById("salary").value;
    var city = document.getElementById("city").value;
    var isValid = true;

    // Validate Full Name
    if (fullName === "") {
        document.getElementById("fullNameError").innerText = "Full Name is required";
        isValid = false;
    } else {
        document.getElementById("fullNameError").innerText = "";
    }

    // Validate Employee Code
    if (empCode === "") {
        document.getElementById("empCodeError").innerText = "Employee Code is required";
        isValid = false;
    } else {
        document.getElementById("empCodeError").innerText = "";
    }

    // Validate Salary
    if (salary === "" || isNaN(salary)) {
        document.getElementById("salaryError").innerText = "Salary must be a number";
        isValid = false;
    } else {
        document.getElementById("salaryError").innerText = "";
    }

    // Validate City
    if (city === "") {
        document.getElementById("cityError").innerText = "City is required";
        isValid = false;
    } else {
        document.getElementById("cityError").innerText = "";
    }

    return isValid;
}
*/

// Create operation
function insertNewRecord(data){
    var table = document.getElementById("employeeList").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);
    var cell1 = newRow.insertCell(0);
        cell1.innerHTML = data.fullName;
    var cell2 = newRow.insertCell(1);
        cell2.innerHTML = data.empCode;
    var cell3 = newRow.insertCell(2);
        cell3.innerHTML = data.salary;
    var cell4 = newRow.insertCell(3);
        cell4.innerHTML = data.city;
    var cell5 = newRow.insertCell(4);
        cell5.innerHTML = `<a href="#" onClick='onEdit(this)'>Edit</a>
                        <a href="#" onClick='onDelete(this)'>Delete</a>`;
}

// To Reset the data of fill input
function resetForm(){
    document.getElementById('fullName').value = '';
    document.getElementById('empCode').value = '';
    document.getElementById('salary').value = '';
    document.getElementById('city').value = '';
    selectedRow = null;
}

// For Edit operation
function onEdit(td){
    selectedRow = td.parentElement.parentElement;
    document.getElementById('fullName').value = selectedRow.cells[0].innerHTML;
    document.getElementById('empCode').value = selectedRow.cells[1].innerHTML;
    document.getElementById('salary').value = selectedRow.cells[2].innerHTML;
    document.getElementById('city').value = selectedRow.cells[3].innerHTML;
}
function updateRecord(formData){
    selectedRow.cells[0].innerHTML = formData.fullName;
    selectedRow.cells[1].innerHTML = formData.empCode;
    selectedRow.cells[2].innerHTML = formData.salary;
    selectedRow.cells[3].innerHTML = formData.city;
}
function onDelete(td){
    if(confirm('Are you sure you want to delete this record?')){
        row = td.parentElement.parentElement;
        document.getElementById('employeeList').deleteRow(row.rowIndex);
        resetForm();
    }    
}